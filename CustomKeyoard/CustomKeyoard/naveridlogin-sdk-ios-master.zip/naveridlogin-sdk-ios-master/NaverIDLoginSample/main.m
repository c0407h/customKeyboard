//
//  main.m
//  NaverOAuthSample
//
//  Created by suejinv on 12. 3. 28..
//  Copyright 2012 NHN Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NaverOAuthSampleAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([NaverOAuthSampleAppDelegate class]));
        return retVal;
    }
}

